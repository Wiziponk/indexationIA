IndexationIA — package for emission 173074

Files:
- program.json             : selected API fields for this emission
- clips/clip_XXXX.txt      : text of each kept clip (title/summary header)
- clips_meta.jsonl         : one JSON per line with start, end, score, title, summary, text
- emb_clips.npy            : (num_clips, dim) clip embeddings (text-embedding-3-large)
- emb_program.npy          : (dim,) program embedding (text-embedding-3-large)
- emb_model.txt            : model identifiers used

